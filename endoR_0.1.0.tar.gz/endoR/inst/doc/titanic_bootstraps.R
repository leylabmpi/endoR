## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.height = 2.5
)

## -----------------------------------------------------------------------------
library(tidyverse)
library(stringr)
library("ggpubr")
library(igraph)
library(ggraph)
library("inTrees")
library(ranger)
library(parallel)
library(caret)
library(endoR)
library(data.table)
library(clustermq)

## -----------------------------------------------------------------------------
sessionInfo()

## -----------------------------------------------------------------------------
summary(titanic)

## -----------------------------------------------------------------------------
summary(titanic$survived)

## -----------------------------------------------------------------------------
n_yes <- sum(titanic$survived == 'yes')
n_samp <- length(titanic$survived)
samp_weight <- round(ifelse(titanic$survived == 'yes', 1-n_yes/n_samp, n_yes/n_samp), digits = 2)
summary(as.factor(samp_weight))

## -----------------------------------------------------------------------------
set.seed(1313)
titanic_rf <- ranger(x = titanic %>% select(-survived), y = titanic$survived
                     , case.weights = samp_weight)
titanic_rf

## -----------------------------------------------------------------------------
titanic_rf$confusion.matrix

## -----------------------------------------------------------------------------
rules <- model2DE_resampling(model = titanic_rf, model_type = 'ranger'
                                 , data = titanic %>% select(-survived)
                                 , target = titanic$survived, classPos = 'yes'
                                 , times = 5
                                 , sample_weight = samp_weight
                                 , discretize = TRUE, K = 2
                                 , prune = TRUE, maxDecay = 0.05, typeDecay = 2 
                                 , filter = FALSE
                                 , in_parallel = TRUE, n_cores = 5
)

## -----------------------------------------------------------------------------
alphas <- evaluateAlpha(rules = rules, alphas = c(1:5, 7, 10)
                        , data = rules$data)

## -----------------------------------------------------------------------------
alphas$summary_table

## -----------------------------------------------------------------------------
de_final <- stabilitySelection(rules = rules, alpha_error = 3)

## -----------------------------------------------------------------------------
de_final$rules_summary %>% subset(inN >= .7*5) %>% 
     presentRules(colN = colnames(rules$data)) %>% head

## -----------------------------------------------------------------------------
plotFeatures(decision_ensemble = de_final)

## -----------------------------------------------------------------------------
p_feat <- plotFeatures(decision_ensemble = de_final, return_all = TRUE
      , levels_order = c('male', 'female'
                         , 'engineering crew', 'restaurant staff', 'deck crew'
                                , 'victualling crew' , '3rd', '2nd', '1st'
                         , 'Belfast', 'Cherbourg', 'Queenstown', 'Southampton'
                         , 'Low', 'Medium', 'High')
                      )
names(p_feat)

## -----------------------------------------------------------------------------
options(repr.plot.width=12, repr.plot.height=3)
ggarrange(p_feat$importance_p + labs('Importance')
          , p_feat$influence_p + labs('Influence')
          , widths = c(0.25, 0.7)) # better! 

## -----------------------------------------------------------------------------
options(repr.plot.width=8, repr.plot.height=5)
plotNetwork(de_final, hide_isolated_nodes = FALSE)

## -----------------------------------------------------------------------------
options(repr.plot.width=8, repr.plot.height=5)
plotNetwork(de_final, hide_isolated_nodes = TRUE
            , layout = 'fr')+ # I usually prefer the 'fr' layout :)
scale_edge_alpha(range = c(0.8, 1))

## -----------------------------------------------------------------------------
preclu <- preCluster(model = titanic_rf, model_type = 'ranger'
                  , data = titanic %>% select(-survived)
                  , target = titanic$survived, classPos = 'yes'
                  , times = 5 # number of bootstraps
                  , sample_weight = samp_weight # sample weight for resampling
                  , discretize = TRUE, K = 2
                  , in_parallel = TRUE, n_cores = 3)

## -----------------------------------------------------------------------------
options(clustermq.scheduler = "multiprocess")
n_cores <- parallel::detectCores()-1 # =3 for me

## -----------------------------------------------------------------------------
rules <- Q(model2DE_cluster
  , partition = preclu$partitions
  , export=list(data = preclu$data
                , target = titanic$survived
                , exec = preclu$exec
                , classPos = 'yes'
                , prune = TRUE, maxDecay = 0.05, typeDecay = 2 
                , filter = FALSE
                , in_parallel = TRUE, n_cores = n_cores
               )
  , n_jobs= 2 # 2 bootstraps will be processed in parallel 
  , pkgs=c('data.table', 'parallel', 'caret', 'stringr', 'scales', 'dplyr'
            , 'inTrees', 'endoR')
  , log_worker=FALSE
 )

## -----------------------------------------------------------------------------
de_final <- stabilitySelection(rules = rules, alpha_error = 3)

## -----------------------------------------------------------------------------
de_final$rules_summary %>% subset(inN >= .7*5) %>% 
     presentRules(colN = colnames(preclu$data)) %>% head

## -----------------------------------------------------------------------------
p_feat <- plotFeatures(decision_ensemble = de_final, return_all = TRUE
      , levels_order = c('male', 'female'
                         , 'engineering crew', 'restaurant staff', 'deck crew'
                                , 'victualling crew' , '3rd', '2nd', '1st'
                         , 'Belfast', 'Cherbourg', 'Queenstown', 'Southampton'
                         , 'Low', 'Medium', 'High')
                      )

## -----------------------------------------------------------------------------
options(repr.plot.width=12, repr.plot.height=3)
ggarrange(p_feat$importance_p + labs(title = 'Importance')
          , p_feat$influence_p + labs(title = 'Influence')
          , widths = c(0.25, 0.7)) # better! 

## -----------------------------------------------------------------------------
options(repr.plot.width=8, repr.plot.height=5)
plotNetwork(de_final, hide_isolated_nodes = FALSE)+
scale_edge_alpha(range = c(0.8, 1))

