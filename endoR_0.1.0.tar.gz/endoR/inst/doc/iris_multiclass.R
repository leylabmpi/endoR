## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 2.5
)

## ----setup, message = FALSE, warning=FALSE------------------------------------
library(endoR)
library(randomForest)
library(tidyverse)
library(caret)
library(ggpubr)
library(ggraph)

## -----------------------------------------------------------------------------
data(iris)
summary(iris)

## -----------------------------------------------------------------------------
set.seed(1313)
mod <- randomForest(Species ~ ., data = iris)
mod

## -----------------------------------------------------------------------------
endo_setosa <- model2DE(model = mod, model_type = 'rf'
                 , data = select(iris, -Species), target = iris$Species
                 , classPos = 'setosa' # our focal class
                 , filter = FALSE 
                 
                 # we filter in K = 3 categories the numerical features
                 , discretize = TRUE, K = 3)

## -----------------------------------------------------------------------------
plotFeatures(endo_setosa, levels_order = c('Low', 'Medium', 'High'))

# The warnings du to the font are due to Windows .. no worries.
plotNetwork(endo_setosa, hide_isolated_nodes = FALSE, layout = 'fr')

## -----------------------------------------------------------------------------
plotNetwork(endo_setosa, hide_isolated_nodes = TRUE, layout = 'fr')+
  theme(legend.box = "horizontal")

## -----------------------------------------------------------------------------
endo_versicolor <- model2DE(model = mod, model_type = 'rf'
                 , data = select(iris, -Species), target = iris$Species
                 , classPos = 'versicolor'
                 , K = 3, discretize = TRUE
                 , filter = TRUE, min_imp = 0.5)

## -----------------------------------------------------------------------------
plotFeatures(endo_versicolor, levels_order = c('Low', 'Medium', 'High'))

## -----------------------------------------------------------------------------
plotNetwork(endo_versicolor, hide_isolated_nodes = FALSE, layout = 'fr'
            # we show only edges that connect 3 nodes max -> removes edges with 
            # lowest importances - for longer paths = more complex network,
            # you can increase path_length
            , path_length = 3  
            )+
  scale_edge_alpha(range = c(0.8,1))+
  theme(legend.box = "horizontal")

